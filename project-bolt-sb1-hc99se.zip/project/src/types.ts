export interface WaterOutage {
  id: string;
  location: {
    lat: number;
    lng: number;
  };
  address: string;
  reportedAt: Date;
  affectedArea: string;
  status: 'active' | 'resolved';
  estimatedResolutionTime?: Date;
}