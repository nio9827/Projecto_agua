import React, { useState } from 'react';
import Map from './components/Map';
import Stats from './components/Stats';
import OutageList from './components/OutageList';
import { WaterOutage } from './types';
import { Droplet } from 'lucide-react';

// Sample data - replace with real API data
const sampleOutages: WaterOutage[] = [
  {
    id: '1',
    location: { lat: 40.7128, lng: -74.0060 },
    address: '123 Broadway',
    reportedAt: new Date(Date.now() - 1000 * 60 * 60 * 5),
    affectedArea: 'Financial District',
    status: 'active',
  },
  {
    id: '2',
    location: { lat: 40.7589, lng: -73.9851 },
    address: '456 5th Avenue',
    reportedAt: new Date(Date.now() - 1000 * 60 * 60 * 2),
    affectedArea: 'Midtown',
    status: 'active',
    estimatedResolutionTime: new Date(Date.now() + 1000 * 60 * 60 * 3),
  },
  {
    id: '3',
    location: { lat: 40.7549, lng: -73.9840 },
    address: '789 Madison Ave',
    reportedAt: new Date(Date.now() - 1000 * 60 * 60 * 8),
    affectedArea: 'Upper East Side',
    status: 'resolved',
  },
];

function App() {
  const [selectedOutage, setSelectedOutage] = useState<WaterOutage | null>(null);

  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Droplet className="h-8 w-8 text-blue-600" />
              <span className="ml-2 text-xl font-semibold">Water Outage Monitor</span>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Stats outages={sampleOutages} />
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 h-[600px]">
            <Map 
              outages={sampleOutages} 
              onMarkerClick={setSelectedOutage}
            />
          </div>
          <div>
            <OutageList outages={sampleOutages} />
          </div>
        </div>

        {selectedOutage && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg p-6 max-w-md w-full">
              <h3 className="text-lg font-semibold mb-2">{selectedOutage.address}</h3>
              <p className="text-gray-600 mb-4">{selectedOutage.affectedArea}</p>
              <div className="space-y-2">
                <p>Status: <span className={selectedOutage.status === 'active' ? 'text-red-500' : 'text-green-500'}>
                  {selectedOutage.status.charAt(0).toUpperCase() + selectedOutage.status.slice(1)}
                </span></p>
                <p>Reported: {selectedOutage.reportedAt.toLocaleString()}</p>
                {selectedOutage.estimatedResolutionTime && (
                  <p>Estimated Resolution: {selectedOutage.estimatedResolutionTime.toLocaleString()}</p>
                )}
              </div>
              <button 
                onClick={() => setSelectedOutage(null)}
                className="mt-4 w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;