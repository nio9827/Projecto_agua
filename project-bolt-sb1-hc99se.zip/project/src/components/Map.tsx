import React, { useEffect, useRef } from 'react';
import { Loader } from '@googlemaps/js-api-loader';
import type { WaterOutage } from '../types';

interface MapProps {
  outages: WaterOutage[];
  onMarkerClick: (outage: WaterOutage) => void;
}

export default function Map({ outages, onMarkerClick }: MapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const googleMapRef = useRef<google.maps.Map | null>(null);
  const markersRef = useRef<google.maps.Marker[]>([]);

  useEffect(() => {
    const loader = new Loader({
      apiKey: import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '',
      version: 'weekly',
    });

    loader.load().then(() => {
      if (mapRef.current && !googleMapRef.current) {
        googleMapRef.current = new google.maps.Map(mapRef.current, {
          center: { lat: 40.7128, lng: -74.0060 }, // Default to NYC
          zoom: 12,
          styles: [
            {
              featureType: 'water',
              elementType: 'geometry',
              stylers: [{ color: '#193341' }]
            },
            {
              featureType: 'landscape',
              elementType: 'geometry',
              stylers: [{ color: '#2c5a71' }]
            }
          ]
        });
      }
    });
  }, []);

  useEffect(() => {
    if (googleMapRef.current) {
      // Clear existing markers
      markersRef.current.forEach(marker => marker.setMap(null));
      markersRef.current = [];

      // Add new markers
      outages.forEach(outage => {
        const marker = new google.maps.Marker({
          position: outage.location,
          map: googleMapRef.current!,
          icon: {
            path: google.maps.SymbolPath.CIRCLE,
            scale: 8,
            fillColor: outage.status === 'active' ? '#ef4444' : '#22c55e',
            fillOpacity: 0.8,
            strokeWeight: 1,
            strokeColor: '#ffffff',
          },
        });

        marker.addListener('click', () => onMarkerClick(outage));
        markersRef.current.push(marker);
      });
    }
  }, [outages, onMarkerClick]);

  return (
    <div ref={mapRef} className="w-full h-full rounded-lg shadow-lg" />
  );
}