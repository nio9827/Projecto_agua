import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { WaterOutage } from '../types';
import { formatDistanceToNow } from 'date-fns';
import { Droplet, Clock, MapPin } from 'lucide-react';

interface StatsProps {
  outages: WaterOutage[];
}

export default function Stats({ outages }: StatsProps) {
  const activeOutages = outages.filter(o => o.status === 'active');
  const chartData = activeOutages.map(outage => ({
    area: outage.affectedArea,
    duration: Math.floor((Date.now() - outage.reportedAt.getTime()) / (1000 * 60 * 60)),
  }));

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-red-100 rounded-full">
            <Droplet className="w-6 h-6 text-red-600" />
          </div>
          <div>
            <p className="text-gray-500">Active Outages</p>
            <h3 className="text-2xl font-bold">{activeOutages.length}</h3>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-blue-100 rounded-full">
            <MapPin className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <p className="text-gray-500">Affected Areas</p>
            <h3 className="text-2xl font-bold">
              {new Set(activeOutages.map(o => o.affectedArea)).size}
            </h3>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-yellow-100 rounded-full">
            <Clock className="w-6 h-6 text-yellow-600" />
          </div>
          <div>
            <p className="text-gray-500">Longest Outage</p>
            <h3 className="text-2xl font-bold">
              {activeOutages.length > 0
                ? formatDistanceToNow(
                    new Date(Math.min(...activeOutages.map(o => o.reportedAt.getTime())))
                  )
                : 'N/A'}
            </h3>
          </div>
        </div>
      </div>

      <div className="md:col-span-3 bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-lg font-semibold mb-4">Outage Duration by Area</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData}>
              <XAxis dataKey="area" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="duration" fill="#3b82f6" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}