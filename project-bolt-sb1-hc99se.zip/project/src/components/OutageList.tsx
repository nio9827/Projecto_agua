import React from 'react';
import { WaterOutage } from '../types';
import { formatDistanceToNow } from 'date-fns';
import { AlertCircle, CheckCircle } from 'lucide-react';

interface OutageListProps {
  outages: WaterOutage[];
}

export default function OutageList({ outages }: OutageListProps) {
  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      <div className="p-4 bg-gray-50 border-b border-gray-200">
        <h3 className="text-lg font-semibold">Recent Outages</h3>
      </div>
      <div className="divide-y divide-gray-200 max-h-[400px] overflow-y-auto">
        {outages.map(outage => (
          <div key={outage.id} className="p-4 hover:bg-gray-50">
            <div className="flex items-start justify-between">
              <div className="flex items-start space-x-3">
                {outage.status === 'active' ? (
                  <AlertCircle className="w-5 h-5 text-red-500 mt-1" />
                ) : (
                  <CheckCircle className="w-5 h-5 text-green-500 mt-1" />
                )}
                <div>
                  <p className="font-medium">{outage.address}</p>
                  <p className="text-sm text-gray-500">{outage.affectedArea}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-500">
                  Reported {formatDistanceToNow(outage.reportedAt)} ago
                </p>
                {outage.estimatedResolutionTime && (
                  <p className="text-sm text-gray-500">
                    Est. Resolution: {formatDistanceToNow(outage.estimatedResolutionTime)}
                  </p>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}